giraphl
=======

giraphl is a library related to Apache Giraph. It is a place to collect things around graph, which fits not into a fork of the Giraph project. 
